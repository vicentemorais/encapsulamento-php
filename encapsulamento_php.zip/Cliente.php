<?php
class Cliente {
    private $id;
    private $nome;
    private $email;
    private $telefone;
    public function __construct($nome, $email, $telefone) {
        $this->setNome($nome);
        $this->setEmail($email);
        $this->setTelefone($telefone);
    }
    public function getId() { return $this->id; }
    public function setId($id) { $this->id = (int)$id; }
    public function getNome() { return $this->nome; }
    public function setNome($nome) {
        if (strlen($nome) < 3) { throw new Exception("O nome deve ter pelo menos 3 caracteres."); }
        $this->nome = $nome;
    }
    public function getEmail() { return $this->email; }
    public function setEmail($email) {
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) { throw new Exception("E-mail inválido."); }
        $this->email = $email;
    }
    public function getTelefone() { return $this->telefone; }
    public function setTelefone($telefone) {
        if (!preg_match('/^[0-9]{10,11}$/', $telefone)) { throw new Exception("Telefone inválido."); }
        $this->telefone = $telefone;
    }
}
?>