<?php
require_once "Model.php";
require_once "Cliente.php";
class ClienteDAO extends Model {
    public function inserir(Cliente $cliente) {
        $sql = "INSERT INTO clientes (nome, email, telefone) VALUES (?, ?, ?)";
        $stmt = $this->conn->prepare($sql);
        $stmt->execute([
            $cliente->getNome(),
            $cliente->getEmail(),
            $cliente->getTelefone()
        ]);
    }
    public function listar() {
        $sql = "SELECT * FROM clientes ORDER BY id DESC";
        $stmt = $this->conn->query($sql);
        $lista = [];
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            $cliente = new Cliente($row['nome'], $row['email'], $row['telefone']);
            $cliente->setId($row['id']);
            $lista[] = $cliente;
        }
        return $lista;
    }
}
?>