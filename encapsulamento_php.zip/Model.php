<?php
class Model {
    private $host = "localhost";
    private $db   = "teste";
    private $user = "root";
    private $pass = "";
    protected $conn;
    public function __construct() { $this->connect(); }
    private function connect() {
        try {
            $this->conn = new PDO("mysql:host={$this->host};dbname={$this->db}", $this->user, $this->pass);
            $this->conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        } catch (PDOException $e) { die("Erro na conexão: " . $e->getMessage()); }
    }
}
?>