<?php
require_once "ClienteDAO.php";
try {
    $dao = new ClienteDAO();
    $cliente = new Cliente("Vicente Morais", "vicente@example.com", "69999999999");
    $dao->inserir($cliente);
    echo "Cliente cadastrado com sucesso!<br><br>";
    echo "<b>Lista de clientes:</b><br>";
    foreach ($dao->listar() as $c) {
        echo $c->getId() . " - " . $c->getNome() . " - " . $c->getEmail() . "<br>";
    }
} catch (Exception $e) {
    echo "Erro: " . $e->getMessage();
}
?>